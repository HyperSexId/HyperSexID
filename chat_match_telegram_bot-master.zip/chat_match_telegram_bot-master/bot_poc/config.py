# coding: utf-8
# 設置 App.config
SECRET_KEY              = 'b07481bjava7704sd25sd27d53000e6b1daI52f47'
SESSION_PROTECTION      = 'strong'
JSON_AS_ASCII           = False
#CSRF_ENABLED           = True
TEMPLATES_AUTO_RELOAD   = True

# 設置 bot_poc.config
BOT_API_KEY             = "1234567890:ABCDEFGHIJKKKKKKKKKK"
BOT_HOOK_URL            = "https://Domainnnnnnnnnnnnn/hook"
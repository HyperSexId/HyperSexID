# coding: utf-8
"""
Routes and views for the flask application.
"""
# coding: utf-8
class ActionResult():
    result:str
    message:str